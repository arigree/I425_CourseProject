/**
 * Author: Jonathan Nguyen
 * Date: 6/21/2026
 * File: Footer.jsx
 * Description: create a common page footer
 */


const Footer = () => {
    const year = new Date().getFullYear();
    return (
        <footer>
            <div className="container">
                <span>&copy;Group Three Corporation. {year}</span>
            </div>
        </footer>
    );
};

export default Footer;