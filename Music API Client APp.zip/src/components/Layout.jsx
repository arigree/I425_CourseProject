/**
 * Author: Jonathan Nguyen
 * Date: 6/21/2026
 * File: Layout.jsx
 * Description: create a common page layout
 */

import {Outlet} from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";

const Layout = () => {
    return (
        <>
            <Header/>
            <Outlet/>
            <Footer />
        </>
    );
};

export default Layout;