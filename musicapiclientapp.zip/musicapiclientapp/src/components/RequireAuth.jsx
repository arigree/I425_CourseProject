/**
 * Name: Benajmin Egger-Torke
 * Date: 06/21/2026
 * File: RequireAuth.jsx
 * Description: page to protect the (insert class here) and classes routes
 */
import {Navigate, useLocation} from "react-router-dom";
import {useAuth} from "../services/useAuth";
const RequireAuth = ({children}) => {
    let {isAuthed} = useAuth();
    let location = useLocation();
    if (!isAuthed) {
        return <Navigate to="/signin" state={{ from: location }} replace />;
    }
    return children;
};
export default RequireAuth;