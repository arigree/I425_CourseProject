//system settings
export const settings = {
    baseApiUrl: "http://localhost/I425/musicapiclientapp"
}