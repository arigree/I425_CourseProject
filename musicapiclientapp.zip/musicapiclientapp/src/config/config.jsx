//system settings
export const settings = {
    baseApiUrl: "http://localhost/I425/I425_CourseProject/api/v1"
}