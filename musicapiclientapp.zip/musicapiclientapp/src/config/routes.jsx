/**
 * Author: Jonathan Nguyen
 * Date: 6/21/2026
 * File: routes.jsx
 * Description:
 */

import {BrowserRouter,Routes,Route}from "react-router-dom";
import Layout from "../components/Layout";
import Home from "../pages/home";
import NoMatch from "../pages/nomatch";
import {AuthProvider} from "../services/useAuth.jsx";
import Signup from "../pages/auth/signup.jsx";
import Signin from "../pages/auth/signin.jsx";
import Signout from "../pages/auth/signout.jsx";
import RequireAuth from "../components/RequireAuth";

const AppRoutes = () => {
    /*Be sure to remove AuthProvider before testing the useXmlHttp stuff, as it will mess it up if
    not removed before some other stuff is added to the class and whatever other ones we will do
     */
    return (
        <BrowserRouter>
            <AuthProvider>
            <Routes>
                <Route path="/" element={<Layout/>}>
                    <Route index element={<Home/>}/>
                    <Route path="*" element={<NoMatch/>}/>
                </Route>
                <Route path="/signin" element={<Signin/>}/>
                <Route path="/signout" element={<Signout/>}/>
                <Route path="/signup" element={<Signup/>}/>
            </Routes>
            </AuthProvider>
        </BrowserRouter>
    );
};

export default AppRoutes;