/**
 * Author: Jonathan Nguyen
 * Date: 6/21/2026
 * File: routes.jsx
 * Description:
 */

import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "../components/Layout";
import Home from "../pages/home";
import NoMatch from "../pages/nomatch";
import { AuthProvider } from "../services/useAuth.jsx";
import Signup from "../pages/auth/signup.jsx";
import Signin from "../pages/auth/signin.jsx";
import Signout from "../pages/auth/signout.jsx";
import RequireAuth from "../components/RequireAuth";
import ArtistsPage from "../pages/ArtistsPage.jsx";
import ArtistDetailsPage from "../pages/ArtistDetailsPage.jsx";

const AppRoutes = () => {
    return (
        <BrowserRouter>
            <AuthProvider>
                <Routes>
                    <Route path="/" element={<Layout />}>
                        <Route index element={<Home />} />
                        <Route
                            path="artists"
                            element={
                                <RequireAuth>
                                    <ArtistsPage />
                                </RequireAuth>
                            }
                        />
                        <Route
                            path="artists/:id"
                            element={
                                <RequireAuth>
                                    <ArtistDetailsPage />
                                </RequireAuth>
                            }
                        />
                        <Route path="*" element={<NoMatch />} />
                        <Route path="/signin" element={<Signin />} />
                        <Route path="/signout" element={<Signout />} />
                        <Route path="/signup" element={<Signup />} />
                    </Route>
                </Routes>
            </AuthProvider>
        </BrowserRouter>
    );
};

export default AppRoutes;