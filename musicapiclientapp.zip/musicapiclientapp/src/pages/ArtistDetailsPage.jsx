/**
 * Name: Arissa Green
 * Date: 06/22/2026
 * File: ArtistDetailsPage.jsx
 * Description: Get and display artist details
 */

import { useEffect, useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import { Alert, Badge, Card, Col, Container, Row, Spinner, Table } from "react-bootstrap";
import useXmlHttp from "../services/useXmlHttp";
import {useAuth} from "../../services/useAuth";

const ArtistDetailsPage = () => {
    const {user} = useAuth();
    //testing
    const params = useParams();
    console.log("artist params:", params);
    const { id } = useParams();
    const artistRequest = useXmlHttp(url, "GET", {Authorization:`Bearer ${user.jwt}`});
    const albumRequest = useXmlHttp(url, "GET", {Authorization:`Bearer ${user.jwt}`});

    useEffect(() => {
        if (!id) return;
        artistRequest.request(`/artist/${id}`);
        albumRequest.request(`/artist/${id}/album`);
    }, [id, artistRequest.request, albumRequest.request]);

    const artist = useMemo(() => {
        const payload = artistRequest.data;

        if (!payload) return null;

        if (payload.artist) return payload.artist;
        if (payload.data?.artist) return payload.data.artist;

        if (Array.isArray(payload.data)) return payload.data[0] ?? null;
        if (payload.data && typeof payload.data === "object") return payload.data;

        if (Array.isArray(payload)) return payload[0] ?? null;
        if (typeof payload === "object") return payload;

        return null;
    }, [artistRequest.data]);

    const albums = useMemo(() => {
        const payload = albumRequest.data;
        if (Array.isArray(payload?.data)) return payload.data;
        if (Array.isArray(payload)) return payload;
        return [];
    }, [albumRequest.data]);

    const loading = artistRequest.isLoading || albumRequest.isLoading;
    const error = artistRequest.error || albumRequest.error;
    //testing
    console.log("artist detail response:", artistRequest.data);
    return (
        <Container className="py-4 main-content">
            <div className="mb-4 d-flex flex-wrap gap-3 align-items-center justify-content-between">
                <div>
                    <h1 className="main-heading mb-1">Artist Details</h1>
                    <p className="text-muted mb-0">View the selected artist and their related albums.</p>
                </div>
                <Link to="/artists" className="btn btn-outline-primary">
                    Back to Artists
                </Link>
            </div>

            {loading && (
                <div className="image-loading justify-content-center py-4">
                    <Spinner animation="border" role="status" />
                </div>
            )}

            {error && <Alert variant="danger">{error}</Alert>}

            {!loading && !error && artist && (
                <Row className="g-4">
                    <Col lg={4}>
                        <Card className="shadow-sm h-100">
                            <Card.Body>
                                <Card.Title>{artist.artistName}</Card.Title>
                                <Card.Subtitle className="mb-3 text-muted">
                                    Artist ID: {artist.id}
                                </Card.Subtitle>

                                <p className="mb-3">{artist.artistDescription || "No description available."}</p>

                                <div className="d-flex flex-wrap gap-2 mb-3">
                                    {artist.joinDate && <Badge bg="primary">Joined: {artist.joinDate}</Badge>}
                                    <Badge bg="secondary">Albums: {albums.length}</Badge>
                                    <Badge bg="success">Songs: {Array.isArray(artist.song) ? artist.song.length : 0}</Badge>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>

                    <Col lg={8}>
                        <Card className="shadow-sm h-100">
                            <Card.Body>
                                <Card.Title className="mb-3">Related Albums</Card.Title>

                                {albums.length === 0 ? (
                                    <Alert variant="info" className="mb-0">
                                        This artist does not have any albums yet.
                                    </Alert>
                                ) : (
                                    <Table responsive hover className="mb-0 align-middle">
                                        <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Album</th>
                                            <th>Release Date</th>
                                            <th>Label ID</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        {albums.map((album) => (
                                            <tr key={album.albumID}>
                                                <td>{album.albumID}</td>
                                                <td>{album.albumTitle}</td>
                                                <td>{album.releaseDate}</td>
                                                <td>{album.labelID}</td>
                                            </tr>
                                        ))}
                                        </tbody>
                                    </Table>
                                )}
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            )}

            {!loading && !error && !artist && (
                <Alert variant="warning">No artist record was found for this ID.</Alert>
            )}
        </Container>
    );
};

export default ArtistDetailsPage;
