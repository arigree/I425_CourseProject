/**
 * Name: Arissa Green
 * Date: 06/22/2026
 * File: ArtistsPage.jsx
 * Description: Display a list of artists in the db
 */

import { useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { Alert, Badge, Card, Col, Container, Row, Spinner } from "react-bootstrap";
import useXmlHttp from "../services/useXmlHttp";
import {useAuth} from "../../services/useAuth";

const ArtistsPage = () => {
    const { data, error, isLoading, request } = useXmlHttp(url, "GET", {Authorization:`Bearer ${user.jwt}`});

    useEffect(() => {
        request("/artist?limit=100&offset=0");
    }, [request]);

    const artists = useMemo(() => {
        if (Array.isArray(data?.data)) {
            return data.data;
        }
        if (Array.isArray(data)) {
            return data;
        }
        return [];
    }, [data]);

    return (
        <Container className="py-4 main-content">
            <div className="mb-4">
                <h1 className="main-heading">Artists</h1>
                <p className="text-muted mb-0">
                    Browse the artist catalog and open any artist to see their albums.
                </p>
            </div>

            {isLoading && (
                <div className="image-loading justify-content-center py-4">
                    <Spinner animation="border" role="status" />
                </div>
            )}

            {error && <Alert variant="danger">{error}</Alert>}

            {!isLoading && !error && artists.length === 0 && (
                <Alert variant="info">No artists were returned by the API.</Alert>
            )}

            <Row xs={1} md={2} lg={3} className="g-4">
                {artists.map((artist) => {
                    const albumCount = Array.isArray(artist.album) ? artist.album.length : 0;
                    const songCount = Array.isArray(artist.song) ? artist.song.length : 0;

                    return (
                        <Col key={artist.artistID}>
                            <Card className="h-100 shadow-sm">
                                <Card.Body className="d-flex flex-column">
                                    <Card.Title className="mb-2">{artist.artistName}</Card.Title>
                                    <Card.Text className="text-muted flex-grow-1">
                                        {artist.artistDescription || "No description available."}
                                    </Card.Text>

                                    <div className="d-flex flex-wrap gap-2 mb-3">
                                        <Badge bg="primary">Albums: {albumCount}</Badge>
                                        <Badge bg="secondary">Songs: {songCount}</Badge>
                                        {artist.joinDate && (
                                            <Badge bg="light" text="dark">
                                                Joined: {artist.joinDate}
                                            </Badge>
                                        )}
                                    </div>

                                    <div className="mt-auto">
                                        <Link className="btn btn-primary w-100" to={`/artists/${artist.artistID}`}>
                                            View details
                                        </Link>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                    );
                })}
            </Row>
        </Container>
    );
};

export default ArtistsPage;
