/**
 * Name: Arissa Green
 * Date: 06/22/2026
 * File: useXmlHttp.jsx
 * Description: Reusable API hook for authenticated XML/HTTP requests. Keeps the JWT in the Authorization header when available.
 */

import { useCallback, useState } from "react";
import { useAuth } from "./useAuth";
import { settings } from "../config/config";

const useXmlHttp = () => {
    const { user } = useAuth();
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    const request = useCallback(
        async (endpoint, options = {}) => {
            const {
                method = "GET",
                body = null,
                headers = {},
            } = options;

            setIsLoading(true);
            setError(null);

            try {
                const response = await fetch(`${settings.baseApiUrl}${endpoint}`, {
                    method,
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json",
                        ...(user?.jwt ? { Authorization: `Bearer ${user.jwt}` } : {}),
                        ...headers,
                    },
                    ...(body !== null ? { body: JSON.stringify(body) } : {}),
                });

                const contentType = response.headers.get("content-type") || "";
                const parsed = contentType.includes("application/json")
                    ? await response.json()
                    : await response.text();

                if (!response.ok) {
                    const message =
                        typeof parsed === "object" && parsed !== null && parsed.message
                            ? parsed.message
                            : `Request failed with status ${response.status}`;
                    throw new Error(message);
                }

                setData(parsed);
                return parsed;
            } catch (err) {
                setError(err.message || "An unexpected error occurred.");
                throw err;
            } finally {
                setIsLoading(false);
            }
        },
        [user?.jwt]
    );

    return { data, error, isLoading, request, setData };
};

export default useXmlHttp;
